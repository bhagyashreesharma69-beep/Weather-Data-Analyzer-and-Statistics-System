# Viva Questions and Answers

1. **Why did you choose Weather Data Analyzer as your project?**
   It's a real-world scenario that naturally fits a list of records,
   and it lets me demonstrate lists, tuples, loops, conditionals and
   basic algorithms in a meaningful way.

2. **Why did you use a list to store the weather records?**
   Because I need to add, remove and update records over time, and
   lists are mutable — they can grow, shrink, and have their elements
   replaced.

3. **Why did you use tuples for individual records instead of lists?**
   Each record has a fixed structure (date, temperature, humidity,
   rainfall) that shouldn't change field-by-field once created. Tuples
   are immutable, which protects the record's integrity, and they
   support convenient unpacking.

4. **What is tuple unpacking?**
   It means assigning each element of a tuple to a separate variable in
   one line, e.g. `date, temp, hum, rain = record`.

5. **Why are tuples useful here specifically?**
   They let me read all four fields of a record in one readable line
   using unpacking, and they guarantee the record isn't accidentally
   modified partway through processing.

6. **How is a list different from a tuple?**
   Lists use square brackets and are mutable (can be changed after
   creation). Tuples use round brackets and are immutable (cannot be
   changed after creation).

7. **Where did you use loops in this project?**
   `for` loops are used to traverse `weather_records` in almost every
   analysis function. `while` loops are used for the main menu (to
   keep showing the menu until Exit) and for input validation retries.

8. **Where did you use if-elif-else?**
   In `weather_classification.py` to classify temperature and rainfall
   into categories, and in `main.py` to decide which function to call
   based on the user's menu choice.

9. **Where did you use nested if?**
   In `weather_classification_menu()`, to check if a day is both "Hot"
   and "Dry" (an if inside another if).

10. **Where did you use functions?**
    Every operation (add, search, sort, classify, etc.) is written as
    its own function with a docstring, spread across 8 modules.

11. **How do you find the maximum temperature?**
    Either with Python's built-in `max()` function on a list of
    temperatures, or manually with a loop that keeps track of the
    largest value seen so far (used in `hottest_day()`).

12. **How do you find the minimum temperature?**
    Same idea as maximum, but keeping track of the smallest value seen
    so far (used in `coldest_day()`).

13. **How do you find the Kth hottest day?**
    I sort a copy of the records by temperature in descending order
    and return the record at index `K-1`.

14. **How does searching work in your project?**
    It's a linear search: I loop through `weather_records` and compare
    each record's date to the date the user typed, stopping with
    `break` when found.

15. **How does sorting work in your project?**
    I implemented a simple bubble sort: repeatedly compare adjacent
    records and swap them if they are in the wrong order, until the
    whole list is sorted.

16. **How do you handle invalid input?**
    Using `try`/`except ValueError` to catch non-numeric input, and
    `if`/`else` range checks (e.g., humidity must be 0–100). Both are
    wrapped in a `while True` loop that keeps asking until valid input
    is given.

17. **Why did you divide the project into modules?**
    To keep each file focused on one responsibility (data management,
    temperature analysis, rainfall analysis, classification,
    statistics, validation), which makes the code easier to read,
    test, and explain.

18. **What are the limitations of this project?**
    Data is stored only in memory and is lost when the program closes;
    there is no database, no GUI, and no real-time weather data.

19. **What future enhancements could be added?**
    A live weather API, a graphical interface, database storage, data
    visualization with charts, and CSV import/export.

20. **Why is the outer structure a list and not a tuple?**
    Because I need to add and remove records — an operation a tuple
    cannot support since tuples are immutable.

21. **Why is each record a tuple and not a list?**
    Because a record's structure (4 fixed fields in a fixed order)
    should not change, so immutability is a helpful guarantee rather
    than a limitation.

22. **How did you "update" a record if tuples are immutable?**
    I built a brand-new tuple with the updated values and replaced the
    old tuple in the list using its index — `weather_records[index] =
    new_tuple`. The list itself is what allows replacement; the tuple
    is simply recreated, not modified.

23. **What does `break` do in your program?**
    It exits a loop immediately. I use it in `search_weather_record()`
    once a match is found, so the loop doesn't keep checking the
    remaining records unnecessarily.

24. **What does `continue` do in your program?**
    It skips the rest of the current loop iteration and goes back to
    the condition check. I use it in `validation.py` to immediately
    re-ask for input when a `ValueError` occurs.

25. **What are the project-defined weather classification rules?**
    Temperature: below 20°C = Cold, 20–30°C = Moderate, above 30°C =
    Hot. Rainfall: 0 mm = Dry, 1–10 mm = Light Rain, 11–25 mm =
    Moderate Rain, above 25 mm = Heavy Rain. These are rules I defined
    for this project, not official meteorological standards.

26. **How do you count how many days were "Hot"?**
    I loop through all records, classify each one's temperature using
    `classify_temperature()`, and increment a counter whenever the
    result is "Hot".

27. **What is the difference between `pop()` and `remove()` on a list?**
    `pop(index)` removes and returns the element at a given index.
    `remove(value)` removes the first element that matches a given
    value, without needing to know its index.

28. **Why did you use `weather_records[:]` before sorting?**
    To clone (copy) the list using slicing, so the sort operates on a
    separate copy and does not disturb the original order of
    `weather_records`.

29. **What data type is `weather_records[0]`?**
    It is a tuple — a single weather record containing (date,
    temperature, humidity, rainfall).

30. **What would happen if you tried to do `record[0] = "new date"`
    directly on a tuple?**
    Python would raise a `TypeError`, because tuples do not support
    item assignment — this is exactly why updates rebuild a new tuple
    instead.
