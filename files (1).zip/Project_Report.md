# Project Report: Weather Data Analyzer and Statistics System

---

## 1. Cover Page

**Project Title:** Weather Data Analyzer and Statistics System
**Course:** Python Programming (Lists, Tuples, Arrays, Control Flow)
**Submission Type:** VITyarthi – Build Your Own Project
**Technology Used:** Python 3 (Standard Library only)

---

## 2. Introduction

Weather is monitored every day in terms of temperature, humidity and
rainfall. Over a period of many days, this data can be analyzed to
answer useful questions: Which was the hottest day? How much rain fell
in total? How many days were dry? This project, the **Weather Data
Analyzer and Statistics System**, is a console-based Python
application that stores a collection of daily weather records and
provides menu-driven options to manage and analyze that data using
fundamental Python programming concepts taught in the course.

---

## 3. Problem Statement

Manually reviewing many days of weather observations to extract
insights (hottest day, total rainfall, number of rainy days, etc.) is
tedious and error-prone. This project automates that process with a
simple, easy-to-understand Python program built entirely from
beginner-level concepts: lists, tuples, loops, conditionals and
functions.

---

## 4. Objectives

- Represent each weather record as a tuple and store all records in a
  list, to demonstrate the appropriate use of both data structures.
- Provide CRUD (Create, Read, Update, Delete) style operations on
  weather records.
- Analyze temperature and rainfall trends using loops and simple
  algorithms (no advanced libraries).
- Classify weather using clearly labeled, project-defined rules.
- Generate summary statistics and a report.
- Demonstrate array-style algorithms: traversal, maximum/minimum,
  sorting, reversing, counting, duplicate removal, partitioning and
  finding the Kth smallest/largest element.

---

## 5. Scope

See `statement.md` for the full scope description. In short: this
project handles an in-memory list of weather records and performs
analysis on it through a text menu. It does not use a database, GUI,
or the internet.

---

## 6. Functional Requirements

| ID | Requirement |
|----|-------------|
| FR1 | The system shall allow adding a new weather record. |
| FR2 | The system shall allow displaying all weather records. |
| FR3 | The system shall allow searching a record by date. |
| FR4 | The system shall allow updating an existing record. |
| FR5 | The system shall allow deleting a record by date. |
| FR6 | The system shall calculate temperature statistics (avg/max/min/hottest/coldest/Kth). |
| FR7 | The system shall calculate rainfall statistics (total/avg/max/min/rainy-dry counts). |
| FR8 | The system shall classify each day's temperature and rainfall. |
| FR9 | The system shall sort records by temperature or rainfall. |
| FR10 | The system shall generate an overall statistics report and a summary report. |
| FR11 | The system shall validate user input and handle errors gracefully. |

---

## 7. Non-Functional Requirements

1. **Usability** – The application has a simple, numbered, menu-driven
   console interface that is easy for a new user to follow.
2. **Reliability** – Invalid inputs (non-numeric menu choice, invalid
   date format, out-of-range humidity, etc.) are handled using
   try/except and if-else checks so the program does not crash.
3. **Maintainability** – The project is divided into 8 separate Python
   modules, each with a single clear responsibility, making it easy to
   locate and modify code.
4. **Performance** – The program uses simple loops (O(n) or O(n²) for
   sorting) which are efficient enough for the small, reasonable-sized
   dataset (a semester's worth of daily weather records).
5. **Error Handling** – The program shows a clear, specific message
   whenever an operation cannot be completed (record not found, empty
   dataset, invalid K value, duplicate date, etc.).

---

## 8. System Architecture

The system follows a simple modular (procedural) architecture. `main.py`
acts as the controller: it shows the menu and calls functions from
the other modules, which perform the actual data management and
analysis. Data flows through a single shared list, `weather_records`,
which is passed as an argument to whichever function needs it.

```mermaid
flowchart TD
    A[main.py - Menu Controller] --> B[weather_data.py - Sample Data]
    A --> C[weather_operations.py - Add/Search/Update/Delete/Display]
    A --> D[temperature_analysis.py - Temperature Analysis]
    A --> E[rainfall_analysis.py - Rainfall Analysis]
    A --> F[weather_classification.py - Classification Rules]
    A --> G[statistics_analysis.py - Overall Stats and Report]
    C --> H[validation.py - Input Validation]
    D --> H
    E --> H
    G --> H
    G --> D
    G --> E
    G --> F
```

---

## 9. Workflow

```mermaid
flowchart TD
    Start([Start Program]) --> LoadData[Load Sample Weather Records]
    LoadData --> ShowMenu[Display Main Menu]
    ShowMenu --> GetChoice[Get Valid Menu Choice]
    GetChoice --> Process{Which Option?}
    Process -->|1-5| DataMgmt[Weather Data Management]
    Process -->|6-8| Analysis[Temperature/Rainfall/Classification]
    Process -->|9-14| Reports[Sort/Stats/Report/Array Demo]
    Process -->|15| Exit([Exit Program])
    DataMgmt --> ShowMenu
    Analysis --> ShowMenu
    Reports --> ShowMenu
```

---

## 10. UML Use Case Diagram (Description)

**Actor:** User (Student / Weather Data Analyst)

**Use Cases:**
- Add Weather Record
- Display Weather Records
- Search Weather Record
- Update Weather Record
- Delete Weather Record
- Analyze Temperature
- Analyze Rainfall
- Classify Weather
- Sort Records
- Find Hottest/Coldest Day
- Find Kth Hottest/Coldest Day
- View Statistics
- Generate Summary Report

```mermaid
flowchart LR
    User((User))
    User --> UC1[Add Weather Record]
    User --> UC2[Display Records]
    User --> UC3[Search Record]
    User --> UC4[Update Record]
    User --> UC5[Delete Record]
    User --> UC6[Analyze Temperature]
    User --> UC7[Analyze Rainfall]
    User --> UC8[Classify Weather]
    User --> UC9[Sort Records]
    User --> UC10[View Statistics]
    User --> UC11[Generate Report]
```

---

## 11. Component / Module Diagram (Description)

Since this project does not use classes (per the syllabus scope), the
"component diagram" below represents Python **modules** and their
relationships instead of classes.

```mermaid
flowchart TD
    main[main.py]
    wd[weather_data.py]
    wo[weather_operations.py]
    ta[temperature_analysis.py]
    ra[rainfall_analysis.py]
    wc[weather_classification.py]
    sa[statistics_analysis.py]
    val[validation.py]

    main --> wd
    main --> wo
    main --> ta
    main --> ra
    main --> wc
    main --> sa
    wo --> val
    ta --> val
    ra --> val
    sa --> ta
    sa --> ra
    sa --> wc
    ta --> wc
```

---

## 12. Sequence Diagram (Description) — "Add Weather Record" flow

```mermaid
sequenceDiagram
    participant U as User
    participant M as main.py
    participant O as weather_operations.py
    participant V as validation.py
    participant L as weather_records (list)

    U->>M: Choose option 1 (Add Record)
    M->>O: add_weather_record(weather_records)
    O->>V: get_valid_date()
    V-->>O: valid date string
    O->>O: is_date_present(weather_records, date)
    O->>V: get_valid_temperature()
    V-->>O: valid temperature
    O->>V: get_valid_humidity()
    V-->>O: valid humidity
    O->>V: get_valid_rainfall()
    V-->>O: valid rainfall
    O->>L: weather_records.append(new_record)
    O-->>U: "Weather record added successfully."
```

---

## 13. Data Structure Design

The core data structure is a **list of tuples**:

```python
weather_records = [
    ("01-09-2026", 32, 65, 5),
    ("02-09-2026", 34, 60, 0),
    ...
]
```

- **List** (outer structure): chosen because it is *mutable* — records
  need to be added (`append`), removed (`pop`), and replaced
  (`weather_records[index] = new_tuple`) as the user manages data.
- **Tuple** (each record): chosen because a single day's weather
  reading is a *fixed-size, fixed-order* group of related values
  (Date, Temperature, Humidity, Rainfall) that should not be
  accidentally modified field-by-field. Tuple unpacking
  (`date, temp, hum, rain = record`) also makes the code very
  readable.

Because tuples are immutable, "updating" a record in this project
means building a brand-new tuple with the new values and replacing the
old tuple in the list by index — this is intentional and is explained
to the evaluator as a demonstration of the list/tuple mutability
difference, not a limitation.

---

## 14. Design Decisions

| Decision | Reason |
|----------|--------|
| Use list of tuples instead of list of lists | Demonstrates tuple immutability and unpacking, and is more appropriate for fixed-structure records. |
| Use manual bubble-sort for "sort by temperature/rainfall" | Shows understanding of a fundamental sorting algorithm rather than relying only on the built-in `sort()`. |
| Split code into 8 files | Satisfies the modular design requirement and keeps each file focused on one responsibility. |
| Centralize input validation in `validation.py` | Avoids duplicating try/except and range-check code across multiple modules. |
| Use project-defined classification thresholds | The syllabus does not teach meteorological standards, so simple, clearly-labeled thresholds are used instead. |

---

## 15. Implementation Details

The project is implemented purely with Python's built-in features:
- `input()` / `print()` for the console interface
- `list` and `tuple` for data storage
- `for` and `while` loops for traversal and repeated menu display
- `if` / `if-else` / `if-elif-else` / nested `if` for decision-making
- `try` / `except ValueError` for input validation
- Functions with docstrings for every reusable operation

No classes, frameworks, databases, or third-party libraries are used,
in line with the syllabus scope.

---

## 16. Python Concepts Used (Mapping Table)

| Syllabus Concept | Where It Is Used in the Project |
|---|---|
| Lists | `weather_records` list; temperature/rainfall/humidity lists in analysis modules |
| Tuples | Each weather record `(date, temp, humidity, rainfall)` |
| Tuple Unpacking | `date, temperature, humidity, rainfall = record` (used in nearly every function) |
| Indexing | `weather_records[index]`, `sorted_temps[k-1]` |
| Slicing | `weather_records[:]` (cloning), `temperatures[::-1]` (reverse) |
| List Traversal | `for record in weather_records:` loops throughout |
| append() | `weather_operations.add_weather_record()` |
| insert() | Documented in Array_and_its_Operations reference; append used for record addition since records are added at the end (insert is demonstrated conceptually in the syllabus material) |
| remove()/pop() | `weather_operations.delete_weather_record()` uses `pop(index)` |
| extend() | Conceptually available for list concatenation; not required in core flow |
| sort()/reverse() | `sorted()` and slicing `[::-1]` used in `statistics_analysis.array_concepts_demo()` |
| Searching | `weather_operations.search_weather_record()` (linear search) |
| Counting | `count_temperature_categories()`, `count_rainy_and_dry_days()` |
| Maximum/Minimum | `hottest_day()`, `coldest_day()`, `day_with_highest_rainfall()`, `max()`/`min()` |
| Duplicate Handling | `remove_duplicate_temperatures()` in `statistics_analysis.py` |
| Partitioning | `partition_temperatures()` in `statistics_analysis.py` |
| Kth Element | `kth_hottest_day()`, `kth_coldest_day()`, `kth_smallest_temperature()` |
| if / if-else / if-elif-else | `weather_classification.py`, `validation.py`, menu handling in `main.py` |
| Nested if | `weather_classification_menu()` (Hot & Dry check) |
| for loop | Traversal in nearly every module |
| while loop | `main()` menu loop; validation retry loops in `validation.py` |
| break / continue | `search_weather_record()` uses `break`; `validation.py` uses `continue` |
| Functions | Every operation is implemented as a function with a docstring |
| Array Concepts (Unit V) | `statistics_analysis.array_concepts_demo()` — traversal, max/min, sort, reverse, counting, duplicate removal, partitioning, Kth smallest |

---

## 17. Testing Approach

Each menu option was manually tested by running `main.py` and
supplying both valid and invalid input to confirm correct behavior and
that the program never crashes on bad input.

## 18. Test Cases

| # | Test Case | Input | Expected Output |
|---|-----------|-------|------------------|
| 1 | Add valid record | Valid date/temp/humidity/rainfall | "Weather record added successfully." |
| 2 | Add duplicate date | Existing date | "A record for this date already exists." |
| 3 | Invalid temperature | `abc` | "Invalid temperature. Please enter a whole number." |
| 4 | Invalid humidity (out of range) | `150` | "Humidity must be between 0 and 100." |
| 5 | Invalid rainfall (negative) | `-5` | "Rainfall cannot be negative." |
| 6 | Invalid date format | `2026/09/01` | "Invalid date format. Please use DD-MM-YYYY." |
| 7 | Search existing date | Existing date | Record details displayed |
| 8 | Search missing date | Unknown date | "No record found for date: ..." |
| 9 | Update existing record | Existing date + new values | "Weather record updated successfully." |
| 10 | Update missing record | Unknown date | "No record found for date: ..." |
| 11 | Delete existing record | Existing date | "Deleted record: (...)" |
| 12 | Delete missing record | Unknown date | "No record found for date: ..." |
| 13 | Invalid menu choice | `99` | "Invalid choice. Please choose a number between 1 and 15" |
| 14 | Non-numeric menu choice | `abc` | "Invalid input. Please enter a number." |
| 15 | Invalid K value (0) | `0` | "K must be between 1 and <n>" |
| 16 | Invalid K value (too large) | `999` | "K must be between 1 and <n>" |
| 17 | Display records on empty dataset | (dataset emptied first) | "No weather records available." |
| 18 | Sort by temperature ascending | Choice 6 in sort menu | Records printed with increasing temperature |
| 19 | Weather classification | Choice 8 in main menu | Each record shown with Temp/Rain class |

All 19 test cases were executed against the program and produced the
expected output without any crash.

---

## 19. Screenshots to Take (for submission)

1. Main menu on program startup
2. Add Weather Record — successful addition
3. Display All Records — full table
4. Search Weather Record — found and not-found cases
5. Update Weather Record — before/after values
6. Delete Weather Record — confirmation message
7. Temperature Analysis submenu with a sample result (e.g., hottest day)
8. Rainfall Analysis submenu with a sample result
9. Weather Classification table output
10. Weather Statistics output
11. Generate Summary Report output
12. Array Concepts Demo output
13. An invalid-input example showing graceful error handling
14. Program exit message

---

## 20. Challenges

- Deciding how to "update" a tuple-based record, since tuples cannot
  be modified in place — solved by rebuilding the tuple and replacing
  it in the list by index.
- Keeping the classification rules simple and clearly labeled as
  project-defined, rather than accidentally implying they were
  official meteorological standards.
- Avoiding duplicate code across the temperature and rainfall modules
  by using very similar, clearly-named helper functions in each.

---

## 21. Learnings

- Practical difference between mutable (list) and immutable (tuple)
  data structures, and when to use each.
- How tuple unpacking makes code that processes structured records
  much more readable.
- How to build a multi-file (modular) Python project where each file
  has a single responsibility.
- How basic validation (try/except, range checks) prevents a
  console program from crashing on bad input.

---

## 22. Future Enhancements

*(Explicitly NOT part of the current basic project — listed only as
possible future improvements.)*

- Integrate a live weather API to fetch real data automatically.
- Build a graphical user interface (GUI) using Tkinter or similar.
- Store records in a database (e.g., SQLite) instead of an in-memory
  list, so data persists between runs.
- Add data visualization (line/bar charts of temperature and rainfall
  trends) using a charting library.
- Add CSV import/export so records can be loaded from or saved to a
  spreadsheet file.

---

## 23. References

1. Course syllabus material: "Session 1 – List", "Session 1 – Tuples",
   "Array and its Operations", "Session 1 and 2 – Python Control Flow"
   (course-provided slides).
2. Lab components: "List and its Operations – Lab Component 6",
   "Tuple and its Operations – Lab Component 7" (course-provided labs).
3. Official Python 3 documentation: https://docs.python.org/3/tutorial/datastructures.html
4. VITyarthi – Build Your Own Project guidelines document (course-provided).

---

## Requirement Compliance Note (Honest Self-Check)

Comparing this implementation against the attached "Build Your Own
Project" guidelines:

- ✅ At least 3 major functional modules — this project has 5+ (Data
  Management, Temperature Analysis, Rainfall Analysis, Classification,
  Statistics).
- ✅ Clear input/output structure and logical workflow — provided via
  the console menu.
- ✅ At least 4 non-functional requirements — provided (Usability,
  Reliability, Maintainability, Performance, Error Handling — 5 given).
- ✅ 5–10 meaningful modules/files — this project has 8 Python files.
- ✅ Problem Statement, Objectives, Functional/Non-Functional
  Requirements, System Architecture, Workflow diagram, UML-style
  diagrams — all included above.
- ⚠️ **Not fully satisfied:** *Version control usage (Git)* — this
  guideline asks for a GitHub repository with commit history. This
  chat-generated project gives you the complete file structure, but
  **you must personally initialize a Git repository, commit the
  files, and push to GitHub** to satisfy this requirement — that step
  cannot be completed on your behalf here.
- ⚠️ **Not fully satisfied:** *ER Diagram / Schema Design* — this
  guideline section only applies "if applicable" (i.e., if a database
  is used). Since this project intentionally uses an in-memory list
  instead of a database (to stay within the syllabus scope), no ER
  diagram is provided. This is noted here rather than silently
  skipped.
- ⚠️ **Partially satisfied:** *Unit tests* — the guideline mentions
  "unit tests or validation tests." This project includes a manually
  executed test case table (Section 18) rather than an automated
  `unittest`/`pytest` suite, since automated testing frameworks are
  outside the taught syllabus. If your evaluator specifically requires
  automated unit tests, let me know and I can add a simple
  `test_weather_analyzer.py` using only `assert` statements (still
  beginner-friendly, no external library).
